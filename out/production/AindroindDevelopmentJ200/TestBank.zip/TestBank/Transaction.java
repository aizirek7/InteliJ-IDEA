package TestBank;

import java.util.Date;

public class Transaction {
    private double amount;
    private Date timeStamp;
    private Account account;
}
