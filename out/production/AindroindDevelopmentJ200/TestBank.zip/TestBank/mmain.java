package TestBank;

import LibraryManagment.Students;

import java.io.*;
import java.sql.Date;
import java.util.ArrayList;


public class mmain {
    public static ArrayList<User> userArrayList = new ArrayList<>();
    public static Bank bank = new Bank("Demir");
    public static Account account = new Account();
    public static User user = new User();
    public static void main(String[] args) throws IOException {
         bank.getCostumers().add(new User("auss","dsf", "12", "12"));
         bank.getCostumers().add(new User("bmn","vbn", "1", "1"));
         user.accountsList.add(new Account(generateID(), 100, "$" , new User("auss","dsf", "12", "12")));
         user.accountsList1.add(new Account(generateID(), 500, "P" , new User("bmn","vbn", "1", "1")));
         BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
         aVoid(reader);
    }
    public static void auth(BufferedReader reader) throws IOException {
        boolean answer = true;
        while (answer){
            System.out.println("1 - Детали");
            System.out.println("2 - Депозитный счет");
            System.out.println("3 - Взять деньги");
            System.out.println("4 - Перевод денег");
            System.out.println("5 - История трансакций");
            System.out.println("9 - Выход");
            int a = Integer.parseInt(reader.readLine());
            switch (a){
                case 1:
                    detail(reader);
                    break;
                case 2:
                    depositCash(reader);
                    break;
                case 3:
                    withdraw(reader);
                    break;
                case 4:
                    transferCash(reader);
                    break;
                case 5:
                    history(reader);
                    break;
                case 9:
                    System.exit(0);
                    break;

            }
        }
    }

    public static void aVoid(BufferedReader reader) throws IOException {
        System.out.println("1 - Авторизация");
        System.out.println("2 - Регистрация");
        int a = Integer.parseInt(reader.readLine());
        if (a == 1){
            aauth(reader);
        }
        else if (a == 2){
            register(reader);
        }


    }

    private static void register(BufferedReader reader) throws IOException {
        System.out.println("Вы увурены что хотите загестрироваться");
        System.out.println("1 - Да");
        System.out.println("2 - Нет");
        int a = Integer.parseInt(reader.readLine());
        if (a == 1) {
            System.out.println("Введите имя");
            String n = reader.readLine();
            System.out.println("Введите фамилию");
            String lastName = reader.readLine();
            System.out.println("Придумайте логин");
            String name1 = reader.readLine();
            System.out.println("Придумайте пароль");
            String name3 = reader.readLine();
            System.out.println("Введите деньги в долларах");
            int m = Integer.parseInt(reader.readLine());
            System.out.println("Введите деньги в рублях");
            int nm = Integer.parseInt(reader.readLine());
            bank.getCostumers().add(new User(n, lastName, name1, name3));
            user.accountsList.add(new Account(generateID(), m, "$", new User(n, lastName, name1, name3)));
            user.accountsList1.add(new Account(generateID(), nm, "P", new User(n, lastName, name1, name3)));
            auth(reader);

            try {
                FileOutputStream outputStream = new FileOutputStream("user");
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

                objectOutputStream.writeObject(bank.getCostumers());
            }
            catch (Exception e){}
        }
        else {
            System.out.println("Вернуться в гланое меню? 1-Да");
            int b = Integer.parseInt(reader.readLine());
            if (b == 1) {
                auth(reader);
            } else {
                System.exit(0);
            }
        }
    }

    private static void aauth(BufferedReader reader) throws IOException {
        System.out.println("Приветсудвуем вас в нашем банке");
        System.out.println("Пожалуйства авторизуйтесь");
        int count = 2;
        for (int i = 3; i >= 1; i--) {
            System.out.println("Введите логин");
            String login = reader.readLine();
            System.out.println("Введите пароль");
            String password = reader.readLine();
            for (Object User : bank.getCostumers()) {
                User students1 = (User) User;
                if (login.equals(students1.getLogin()) && password.equals(students1.getPassword())) {
                    System.out.println("Вернуться в гланое меню? 1-Да");
                    int b = Integer.parseInt(reader.readLine());
                    if (b == 1) {
                        auth(reader);
                    } else {
                        System.exit(0);
                    }
                } else {
                    System.out.println("Неверные данные у вас осталось попыток " + (count--));
                    break;
                }
            }
        }

    }

    private static void history(BufferedReader reader) {

    }

    private static void transferCash(BufferedReader reader) {
    }

    private static void withdraw(BufferedReader reader) throws IOException {
        System.out.println("Вы точно хотите взять наличные");
        System.out.println("1 - Да");
        System.out.println("2 - Нет");
        int a = Integer.parseInt(reader.readLine());
        if (a == 1){
            withdrawCash(reader);
        }
        if (a == 2){
            auth(reader);
        }

    }

    private static void withdrawCash(BufferedReader reader) throws IOException {
        System.out.println("С какого счета вы хотите взять деньги");
        System.out.println("1 - $");
        System.out.println("2 - P");
        int num = Integer.parseInt(reader.readLine());
        System.out.println("Введите логин и пароль");
        String m = reader.readLine();
        String b = reader.readLine();
        if (num == 1) {
            for (Account account : user.accountsList) {
                if (m.equals(account.getAccountHolder().getLogin()) && b.equals(account.getAccountHolder().getPassword())) {
                    System.out.println("Введите ту сумму денег которую вы хотите");
                    int a = Integer.parseInt(reader.readLine());
                    int c1 = (int) (account.getBalance() - a);
                    account.setBalance(c1);
                }
            }
        }
        if (num == 2){
            for (Account account : user.accountsList1) {
                if (m.equals(account.getAccountHolder().getLogin()) && b.equals(account.getAccountHolder().getPassword())) {
                    System.out.println("Введите ту сумму денег которую вы хотите");
                    int a = Integer.parseInt(reader.readLine());
                    int c1 = (int) (account.getBalance() - a);
                    account.setBalance(c1);
                }
            }
        }
    }




    private static void depositCash(BufferedReader reader) throws IOException {
        System.out.println("Вы хотите оставит деньги на дипозитном счету?");
        System.out.println("1 - Да");
        System.out.println("2 - Нет");
        int a = Integer.parseInt(reader.readLine());
        if (a == 1){
            deposit(reader);

        }
        System.out.println("Вернуться в гланое меню? 1-Да");
        int b = Integer.parseInt(reader.readLine());
        if (b == 1) {
            auth(reader);
        } else {
            System.exit(0);
        }




    }

    public static void deposit(BufferedReader reader) throws IOException {
        System.out.println("С какого счета вы хотите открыть дипозитный счет");
        System.out.println("1 - $");
        System.out.println("2 - P");
        int num = Integer.parseInt(reader.readLine());
        System.out.println("Введите логин и пароль");
        String m = reader.readLine();
        String b = reader.readLine();
        if (num == 1){
            for (Account account : user.accountsList) {
                if (m.equals(account.getAccountHolder().getLogin()) && b.equals(account.getAccountHolder().getPassword())){
                    System.out.println("Введите ту сумму денег которую вы хотите");
                    int a = Integer.parseInt(reader.readLine());
                    int c1 = (int) (account.getBalance() - a);
                    account.setBalance(c1);
                    if (a <= 100){
                        int c = a + (a/100) * 5;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                    if (a <= 500){
                        int c = a + (a/100) * 15;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                    else if (a > 500){
                        int c = a + (a/100) * 50;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                }

            }
        }
        else if (num == 2){
            for (Account account : user.accountsList1) {
                if (m.equals(account.getAccountHolder().getLogin()) && b.equals(account.getAccountHolder().getPassword())){
                    System.out.println("Введите ту сумму денег которую вы хотите");
                    int a = Integer.parseInt(reader.readLine());
                    int c1 = (int) (account.getBalance() - a);
                    account.setBalance(c1);
                    if (a <= 100){
                        int c = a + (a/100) * 5;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                    if (a <= 500){
                        int c = a + (a/100) * 15;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                    else if (a > 500){
                        int c = a + (a/100) * 50;
                        System.out.println(" Ваш дипозтный счет через год: " + c);
                    }
                }
            }
        }




    }

    private static void detail(BufferedReader reader) {
        for (Object students : bank.getCostumers()) {
            User students1 = (User) students;
            System.out.println("Имя: " + students1.getFirsName() + " Фамилие: " + students1.getLastName() +
                    " Кол - во аккаунтов " + students1.getAccountsList() + " Логин " + students1.getLogin()
            + " Пароль: " + students1.getPassword() + " ID: " + generateID() + " Сумма денег: ");
        }
    }
    //Генерация случайного ID
    public static int generateID() {
        int id = (int) (Math.random() * 89999) + 10000;
        boolean answer = checkID(id);
        if (answer) {
            return id;
        } else {
            return generateID();
        }
    }

    //Проверка ID
    public static boolean checkID(int id) {
        for (User students : bank.getCostumers()) {
            if (id == students.getId()) {
                return false;
            }
        }
        return true;
    }

}
